package web;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/Servlet")
public class Servlet extends HttpServlet {

    protected void doPost(HttpServletResponse response, HttpServletRequest request) {
        
    }
}
